import fs from 'fs';
import path from 'path';
import JSZip from 'jszip';

const EXCLUDE_DIRS = new Set([
  'node_modules',
  '.git',
  'dist',
  '.cache',
  '__pycache__',
  '.aistudio',
]);

const EXCLUDE_EXTS = new Set([
  '.pyc',
  '.apk',
  '.zip',
]);

/**
 * Programmatically packages the entire project directory into a raw ZIP archive.
 * Includes:
 * - .github/workflows/build-apk.yml
 * - flutter_app/ (pubspec.yaml, lib/, android/, etc.)
 * - server/
 * - src/
 * - README.md, README_APK_BUILD.md, package.json, tsconfig.json, vite.config.ts, index.html
 */
export async function createProjectSourceZip(baseDir: string): Promise<Buffer> {
  const zip = new JSZip();

  function addDirectoryToZip(currentDir: string, rootDir: string) {
    const entries = fs.readdirSync(currentDir, { withFileTypes: true });

    for (const entry of entries) {
      const name = entry.name;
      const fullPath = path.join(currentDir, name);
      const relativePath = path.relative(rootDir, fullPath);

      if (entry.isDirectory()) {
        if (EXCLUDE_DIRS.has(name) || relativePath.startsWith('.aistudio') || relativePath.startsWith('dist')) {
          continue;
        }
        addDirectoryToZip(fullPath, rootDir);
      } else if (entry.isFile()) {
        const ext = path.extname(name);
        if (EXCLUDE_EXTS.has(ext)) {
          continue;
        }
        if (name.endsWith('.apk') || name.endsWith('.zip')) {
          continue;
        }

        try {
          const content = fs.readFileSync(fullPath);
          // Preserve normal forward-slash file paths in ZIP
          const zipEntryPath = relativePath.split(path.sep).join('/');
          zip.file(zipEntryPath, content, {
            binary: true,
            date: new Date(),
          });
        } catch (err) {
          console.warn(`Could not read file for zip: ${fullPath}`, err);
        }
      }
    }
  }

  addDirectoryToZip(baseDir, baseDir);

  const buffer = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: {
      level: 6,
    },
  });

  return buffer;
}
