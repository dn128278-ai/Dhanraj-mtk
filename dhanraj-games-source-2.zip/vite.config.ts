import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import fs from 'fs';
import { execSync } from 'child_process';
import { defineConfig, Plugin } from 'vite';

function downloadServePlugin(): Plugin {
  return {
    name: 'download-serve-plugin',
    configureServer(server) {
      server.middlewares.use((req, res, next) => {
        const url = req.url?.split('?')[0];
        
        if (url === '/api/download/apk' || url === '/downloads/dhanraj-games-release.apk' || url === '/downloads/dhanraj-games-v1.0.0.apk') {
          const apkPath = path.resolve(__dirname, 'public/downloads/dhanraj-games-release.apk');
          if (!fs.existsSync(apkPath)) {
            try {
              execSync('python3 scripts/build_artifacts.py', { cwd: __dirname });
            } catch (e) {
              console.error('Failed to build artifacts:', e);
            }
          }
          if (fs.existsSync(apkPath)) {
            const stat = fs.statSync(apkPath);
            res.writeHead(200, {
              'Content-Type': 'application/vnd.android.package-archive',
              'Content-Length': stat.size,
              'Content-Disposition': 'attachment; filename="dhanraj-games-v1.0.0.apk"',
              'Cache-Control': 'no-cache',
            });
            fs.createReadStream(apkPath).pipe(res);
            return;
          }
        }

        if (url === '/api/download-source-zip' || url === '/api/download/project-zip' || url === '/downloads/dhanraj-games-project.zip' || url === '/downloads/dhanraj-games-full-project.zip') {
          try {
            execSync('python3 scripts/build_artifacts.py', { cwd: __dirname });
          } catch (e) {
            console.error('Failed to build artifacts:', e);
          }
          const zipPath = path.resolve(__dirname, 'public/downloads/dhanraj-games-project.zip');
          if (fs.existsSync(zipPath)) {
            const stat = fs.statSync(zipPath);
            res.writeHead(200, {
              'Content-Type': 'application/zip',
              'Content-Length': stat.size,
              'Content-Disposition': 'attachment; filename="dhanraj-games-source.zip"',
              'Cache-Control': 'no-cache, no-store, must-revalidate',
            });
            fs.createReadStream(zipPath).pipe(res);
            return;
          }
        }

        next();
      });
    },
  };
}

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss(), downloadServePlugin()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});

