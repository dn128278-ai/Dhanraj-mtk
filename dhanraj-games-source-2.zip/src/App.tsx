import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { PhoneLoginScreen } from './components/PhoneLoginScreen';
import { ProfileSetupScreen } from './components/ProfileSetupScreen';
import { CreateMpinScreen } from './components/CreateMpinScreen';
import { MpinLoginScreen } from './components/MpinLoginScreen';
import { HomeDashboard } from './components/HomeDashboard';
import { HistoryHub } from './components/HistoryHub';
import { PassbookScreen } from './components/PassbookScreen';
import { FundsHub } from './components/funds/FundsHub';
import { SupportScreen } from './components/SupportScreen';
import { BottomNavBar } from './components/BottomNavBar';
import { SidebarDrawer } from './components/SidebarDrawer';
import { NotificationsModal } from './components/NotificationsModal';
import { FlutterCodeCenterModal } from './components/FlutterCodeCenterModal';
import { GameCenterScreen } from './components/bidding/GameCenterScreen';
import { SingleDigitBidScreen } from './components/bidding/SingleDigitBidScreen';
import { JodiDigitBidScreen } from './components/bidding/JodiDigitBidScreen';
import { PanaBidScreen } from './components/bidding/PanaBidScreen';
import { TriplePanaBidScreen } from './components/bidding/TriplePanaBidScreen';
import { MotorBidScreen } from './components/bidding/MotorBidScreen';
import {
  Smartphone,
  Monitor,
  Code2,
  ArrowDownToLine,
  FolderArchive,
  CheckCircle2,
  Sparkles,
} from 'lucide-react';
import { GameModeType } from './types';
import { downloadFileSafely } from './utils/downloader';

const AppContent: React.FC = () => {
  const {
    activeScreen,
    setActiveScreen,
    isAuthenticated,
    selectedMarketForBid,
    setSelectedMarketForBid,
    selectedGameMode,
    setSelectedGameMode,
    markets,
  } = useApp();
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [flutterModalOpen, setFlutterModalOpen] = useState(false);
  const [isMobileFrame, setIsMobileFrame] = useState(true);
  const [isApkDownloading, setIsApkDownloading] = useState(false);
  const [isZipDownloading, setIsZipDownloading] = useState(false);
  const [downloadToast, setDownloadToast] = useState<{
    text: string;
    type: 'apk' | 'zip';
  } | null>(null);

  const triggerDownload = async (url: string, filename: string, type: 'apk' | 'zip') => {
    if (type === 'apk') {
      setIsApkDownloading(true);
      setDownloadToast({ text: 'Downloading Release APK (dhanraj-games-v1.0.0.apk)...', type: 'apk' });
    } else {
      setIsZipDownloading(true);
      setDownloadToast({ text: 'Packaging & downloading raw project source code ZIP...', type: 'zip' });
    }

    const res = await downloadFileSafely(url, filename, type);

    setDownloadToast({
      text: res.message,
      type,
    });

    setIsApkDownloading(false);
    setIsZipDownloading(false);
    setTimeout(() => setDownloadToast(null), 3500);
  };

  // Active market fallback to Kalyan or Sridevi Night if not set
  const currentMarket = selectedMarketForBid || markets.find((m) => m.name === 'SRIDEVI NIGHT') || markets[11];


  // Determine which main view to render
  const renderScreen = () => {
    switch (activeScreen) {
      case 'phone_login':
        return <PhoneLoginScreen />;
      case 'profile_setup':
        return <ProfileSetupScreen />;
      case 'create_mpin':
        return <CreateMpinScreen />;
      case 'mpin_login':
        return <MpinLoginScreen />;
      case 'home':
        return (
          <HomeDashboard
            onOpenDrawer={() => setDrawerOpen(true)}
            onOpenNotifications={() => setNotificationsOpen(true)}
          />
        );
      case 'game_center':
        return (
          <GameCenterScreen
            market={currentMarket}
            onBack={() => setActiveScreen('home')}
            onSelectGame={(game: GameModeType) => {
              setSelectedGameMode(game);
              setActiveScreen('bidding_screen');
            }}
          />
        );
      case 'bidding_screen':
        if (!selectedGameMode) {
          return (
            <GameCenterScreen
              market={currentMarket}
              onBack={() => setActiveScreen('home')}
              onSelectGame={(game: GameModeType) => {
                setSelectedGameMode(game);
                setActiveScreen('bidding_screen');
              }}
            />
          );
        }

        if (selectedGameMode === 'Single Digit') {
          return (
            <SingleDigitBidScreen
              market={currentMarket}
              isBulk={false}
              onBack={() => setActiveScreen('game_center')}
            />
          );
        }
        if (selectedGameMode === 'Single Digit Bulk') {
          return (
            <SingleDigitBidScreen
              market={currentMarket}
              isBulk={true}
              onBack={() => setActiveScreen('game_center')}
            />
          );
        }
        if (selectedGameMode === 'Jodi Digit') {
          return (
            <JodiDigitBidScreen
              market={currentMarket}
              isBulk={false}
              onBack={() => setActiveScreen('game_center')}
            />
          );
        }
        if (selectedGameMode === 'Jodi Digit Bulk') {
          return (
            <JodiDigitBidScreen
              market={currentMarket}
              isBulk={true}
              onBack={() => setActiveScreen('game_center')}
            />
          );
        }
        if (
          selectedGameMode === 'Single Pana' ||
          selectedGameMode === 'Single Pana Bulk' ||
          selectedGameMode === 'Double Pana' ||
          selectedGameMode === 'Double Pana Bulk'
        ) {
          return (
            <PanaBidScreen
              market={currentMarket}
              gameType={selectedGameMode}
              onBack={() => setActiveScreen('game_center')}
            />
          );
        }
        if (selectedGameMode === 'Triple Pana') {
          return (
            <TriplePanaBidScreen
              market={currentMarket}
              onBack={() => setActiveScreen('game_center')}
            />
          );
        }
        // Other special game modes: SP Motor, DP Motor, Red Bracket, Group Jodi, SP DP TP
        return (
          <MotorBidScreen
            market={currentMarket}
            gameType={selectedGameMode}
            onBack={() => setActiveScreen('game_center')}
          />
        );

      case 'history':
      case 'bid_history':
      case 'result_history':
        return (
          <HistoryHub
            onOpenDrawer={() => setDrawerOpen(true)}
            onOpenNotifications={() => setNotificationsOpen(true)}
          />
        );
      case 'passbook':
        return <PassbookScreen />;
      case 'funds':
      case 'add_fund':
      case 'withdraw_fund':
      case 'bank_details':
      case 'deposit_history':
      case 'withdrawal_history':
        return (
          <FundsHub
            onOpenDrawer={() => setDrawerOpen(true)}
            onOpenNotifications={() => setNotificationsOpen(true)}
          />
        );
      case 'support':
        return <SupportScreen />;
      default:
        return (
          <HomeDashboard
            onOpenDrawer={() => setDrawerOpen(true)}
            onOpenNotifications={() => setNotificationsOpen(true)}
          />
        );
    }
  };

  const showBottomNav =
    isAuthenticated &&
    ['home', 'history', 'passbook', 'funds', 'support'].includes(activeScreen);

  return (
    <div className="min-h-screen bg-neutral-950 flex flex-col items-center justify-start sm:justify-center p-2 sm:p-4 text-neutral-100">
      {/* Toast Notification for Downloads */}
      {downloadToast && (
        <div
          className={`fixed top-4 z-50 px-4 py-2.5 rounded-2xl shadow-2xl flex items-center gap-2.5 text-xs sm:text-sm font-semibold border backdrop-blur-md transition-all animate-in slide-in-from-top duration-300 ${
            downloadToast.type === 'apk'
              ? 'bg-emerald-950/95 text-emerald-200 border-emerald-500/50 shadow-emerald-950/80'
              : 'bg-orange-950/95 text-orange-200 border-orange-500/50 shadow-orange-950/80'
          }`}
        >
          <CheckCircle2 size={16} className={downloadToast.type === 'apk' ? 'text-emerald-400' : 'text-orange-400'} />
          <span>{downloadToast.text}</span>
        </div>
      )}

      {/* Top Floating Control & Download Bar (RAMA777 Emulator Style) */}
      <header className="w-full max-w-[420px] md:max-w-2xl mx-auto py-2 px-2 sm:px-3 mb-1.5 flex flex-wrap items-center justify-between gap-2 text-xs">
        {/* App Title & Version Badge */}
        <div className="flex items-center gap-2 bg-neutral-900/90 border border-neutral-800/90 px-2.5 py-1.5 rounded-xl shadow-xs">
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
          </span>
          <span className="font-bold text-white tracking-wide text-xs sm:text-sm">Dhan Raj Games</span>
          <span className="bg-emerald-950 text-emerald-400 border border-emerald-500/40 px-1.5 py-0.5 rounded text-[10px] font-semibold">
            v1.0.0
          </span>
        </div>

        {/* Action Button Bar */}
        <div className="flex items-center flex-wrap gap-1.5 sm:gap-2">
          {/* Prominent Green "Download APK" Button */}
          <button
            onClick={() => triggerDownload('/api/download/apk', 'dhanraj-games-v1.0.0.apk', 'apk')}
            disabled={isApkDownloading}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-500 hover:to-green-500 text-white font-bold text-xs shadow-md shadow-emerald-950/60 active:scale-95 transition-all border border-emerald-400/40 cursor-pointer disabled:opacity-75"
            title="Download Standalone Signed Release APK (547 KB)"
          >
            <ArrowDownToLine size={15} className={isApkDownloading ? 'animate-bounce' : ''} />
            <span>{isApkDownloading ? 'Downloading...' : 'Download APK'}</span>
            <span className="bg-emerald-950/80 text-emerald-200 text-[10px] px-1.5 py-0.5 rounded font-mono font-normal hidden xs:inline">
              .apk
            </span>
          </button>

          {/* Prominent Orange "Download Project ZIP" Button */}
          <button
            onClick={() => triggerDownload('/api/download-source-zip', 'dhanraj-games-source.zip', 'zip')}
            disabled={isZipDownloading}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white font-bold text-xs shadow-md shadow-orange-950/60 active:scale-95 transition-all border border-orange-400/40 cursor-pointer disabled:opacity-75"
            title="Download Full Project Source ZIP (Raw Flutter App + .github/workflows + Backend)"
          >
            <FolderArchive size={15} className={isZipDownloading ? 'animate-bounce' : ''} />
            <span className="hidden sm:inline">{isZipDownloading ? 'Packaging ZIP...' : 'Download Project ZIP'}</span>
            <span className="sm:hidden">{isZipDownloading ? 'Zipping...' : 'Project ZIP'}</span>
            <span className="bg-orange-950/80 text-orange-200 text-[10px] px-1.5 py-0.5 rounded font-mono font-normal hidden xs:inline">
              .zip
            </span>
          </button>

          {/* Flutter & Backend Source Code Modal Button */}
          <button
            onClick={() => setFlutterModalOpen(true)}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-semibold border border-neutral-700 active:scale-95 transition text-xs shadow-xs"
            title="View & Copy Flutter Source Code"
          >
            <Code2 size={14} className="text-amber-400" />
            <span className="hidden md:inline">Flutter Code</span>
          </button>

          {/* Toggle Device Frame */}
          <button
            onClick={() => setIsMobileFrame(!isMobileFrame)}
            className="p-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 border border-neutral-700 hidden md:flex items-center gap-1 transition text-xs"
            title="Toggle Device Frame"
          >
            {isMobileFrame ? <Monitor size={14} /> : <Smartphone size={14} />}
            <span className="hidden xl:inline">{isMobileFrame ? 'Full' : 'Phone'}</span>
          </button>
        </div>
      </header>

      {/* Main Container / Mobile Device Frame */}
      <div
        className={`w-full transition-all duration-300 ${
          isMobileFrame
            ? 'max-w-[420px] h-[calc(100dvh-56px)] sm:h-[844px] sm:rounded-[44px] shadow-2xl sm:ring-8 sm:ring-neutral-800'
            : 'max-w-2xl h-[calc(100dvh-56px)] sm:h-[90vh] sm:rounded-3xl shadow-2xl'
        } bg-white text-neutral-900 flex flex-col overflow-hidden relative`}
      >
        {/* Phone Preview Bezel Header Bar with Direct Download Anchors */}
        <div className="bg-neutral-900 text-neutral-200 px-3 py-1.5 flex items-center justify-between text-[11px] border-b border-neutral-800 sm:rounded-t-[36px]">
          <div className="flex items-center gap-1.5 font-medium">
            <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block animate-pulse" />
            <span className="text-neutral-300">Android Emulator</span>
            <span className="text-neutral-500 hidden xs:inline">• com.dhanraj.games</span>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => triggerDownload('/api/download/apk', 'dhanraj-games-v1.0.0.apk', 'apk')}
              className="text-emerald-400 hover:text-emerald-300 font-bold flex items-center gap-1 bg-emerald-950/80 hover:bg-emerald-900 px-2 py-0.5 rounded-md border border-emerald-500/40 transition active:scale-95"
            >
              <ArrowDownToLine size={11} />
              <span>APK</span>
            </button>
            <button
              onClick={() => triggerDownload('/api/download/project-zip', 'dhanraj-games-project.zip', 'zip')}
              className="text-orange-400 hover:text-orange-300 font-bold flex items-center gap-1 bg-orange-950/80 hover:bg-orange-900 px-2 py-0.5 rounded-md border border-orange-500/40 transition active:scale-95"
            >
              <FolderArchive size={11} />
              <span>ZIP</span>
            </button>
          </div>
        </div>

        {/* Dynamic Screen View */}
        <div
          className={`flex-1 ${

            activeScreen === 'home' ? 'overflow-hidden' : 'overflow-y-auto'
          } flex flex-col relative bg-neutral-100 min-h-0`}
        >
          {renderScreen()}
        </div>

        {/* Bottom Navigation */}
        {showBottomNav && <BottomNavBar />}

        {/* Sidebar Drawer */}
        <SidebarDrawer
          isOpen={drawerOpen}
          onClose={() => setDrawerOpen(false)}
          onOpenCodeCenter={() => setFlutterModalOpen(true)}
        />

        {/* Notifications Modal */}
        <NotificationsModal
          isOpen={notificationsOpen}
          onClose={() => setNotificationsOpen(false)}
        />
      </div>

      {/* Flutter & Backend Source Code Modal */}
      <FlutterCodeCenterModal
        isOpen={flutterModalOpen}
        onClose={() => setFlutterModalOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
