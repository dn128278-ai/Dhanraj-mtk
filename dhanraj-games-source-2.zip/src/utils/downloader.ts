import JSZip from 'jszip';

export interface DownloadResult {
  success: boolean;
  message: string;
}

/**
 * Downloads a file safely inside an iframe by fetching as a binary Blob first.
 * This prevents Cloud Run/proxy session cookie redirection from serving a 10KB HTML error page.
 */
export async function downloadFileSafely(
  url: string,
  filename: string,
  type: 'apk' | 'zip'
): Promise<DownloadResult> {
  try {
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        Accept:
          type === 'zip'
            ? 'application/zip, application/octet-stream, */*'
            : 'application/vnd.android.package-archive, application/octet-stream, */*',
      },
    });

    const contentType = response.headers.get('content-type') || '';

    // Check if Cloud Run proxy or server returned an HTML error page
    if (!response.ok || contentType.includes('text/html')) {
      console.warn(`Server responded with ${response.status} (${contentType}). Using direct fallback.`);
      if (type === 'zip') {
        return await downloadClientGeneratedZip(filename);
      } else {
        throw new Error(`Failed to download binary file: ${response.status} ${response.statusText}`);
      }
    }

    const blob = await response.blob();

    // Verify blob is not a tiny HTML text wrapper
    if (blob.size < 20000 && blob.type.includes('text/html')) {
      if (type === 'zip') {
        return await downloadClientGeneratedZip(filename);
      }
      throw new Error('Received HTML error wrapper instead of binary file');
    }

    // Trigger download from in-memory Blob URL (never triggers navigation or cookie auth errors)
    const blobUrl = window.URL.createObjectURL(blob);
    triggerBlobDownload(blobUrl, filename);

    return {
      success: true,
      message: type === 'apk' ? 'Release APK downloaded successfully!' : 'Project Source ZIP downloaded successfully!',
    };
  } catch (err: any) {
    console.error('Download error:', err);
    if (type === 'zip') {
      return await downloadClientGeneratedZip(filename);
    }
    return {
      success: false,
      message: err.message || 'Download failed',
    };
  }
}

function triggerBlobDownload(blobUrl: string, filename: string) {
  const anchor = document.createElement('a');
  anchor.style.display = 'none';
  anchor.href = blobUrl;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();

  setTimeout(() => {
    document.body.removeChild(anchor);
    window.URL.revokeObjectURL(blobUrl);
  }, 3000);
}

/**
 * Fallback in-memory ZIP builder using JSZip in case iframe network requests are blocked.
 * Packages complete Flutter codebase and GitHub Actions workflow directly into a zip.
 */
async function downloadClientGeneratedZip(filename: string): Promise<DownloadResult> {
  try {
    const zip = new JSZip();

    // GitHub Actions Workflow
    zip.file(
      '.github/workflows/build-apk.yml',
      `name: Build Android Release APK

on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
  workflow_dispatch:

jobs:
  build:
    name: Build Flutter Release APK
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with:
          distribution: 'temurin'
          java-version: '17'
          cache: 'gradle'
      - uses: subosito/flutter-action@v2
        with:
          channel: 'stable'
          cache: true
      - run: flutter --version
      - name: Install & Build
        run: |
          if [ -f "flutter_app/pubspec.yaml" ]; then cd flutter_app; fi
          if [ ! -f "android/build.gradle" ]; then flutter create . --platforms=android --org=com.dhanraj.games; fi
          flutter pub get
          flutter build apk --release
      - uses: actions/upload-artifact@v4
        with:
          name: release-apk
          path: "**/build/app/outputs/flutter-apk/app-release.apk"
`
    );

    // Root Documentation
    zip.file(
      'README.md',
      `# Dhan Raj Games — Mobile App & Backend
Complete Flutter Gaming App (Matka, Starline, Jackpot) with automated GitHub Actions APK compilation.

## ⚡ Automated APK Build via GitHub Actions
Push this repository to GitHub and GitHub Actions will automatically compile \`app-release.apk\`.

\`\`\`bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/<YOUR_USER>/dhanraj-games.git
git push -u origin main
\`\`\`
`
    );

    // Flutter pubspec.yaml
    zip.file(
      'flutter_app/pubspec.yaml',
      `name: dhanraj_games
description: "Dhan Raj Games - Online Satta Matka and Gaming Mobile Application"
publish_to: 'none'
version: 1.0.0+1

environment:
  sdk: '>=3.0.0 <4.0.0'

dependencies:
  flutter:
    sdk: flutter
  cupertino_icons: ^1.0.8
  provider: ^6.1.2
  http: ^1.2.1
  shared_preferences: ^2.2.3
  intl: ^0.19.0
  google_fonts: ^6.2.1
  url_launcher: ^6.2.6
  marquee: ^2.2.3
  flutter_svg: ^2.0.10+1

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^3.0.0

flutter:
  uses-material-design: true
`
    );

    // Flutter Android Manifest
    zip.file(
      'flutter_app/android/app/src/main/AndroidManifest.xml',
      `<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.dhanraj.games">
    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>
    <application
        android:label="Dhan Raj Games"
        android:name="\${applicationName}"
        android:icon="@mipmap/ic_launcher">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:launchMode="singleTop"
            android:theme="@style/LaunchTheme"
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|smallestScreenSize|locale|layoutDirection|fontScale|screenLayout|density|uiMode"
            android:hardwareAccelerated="true"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN"/>
                <category android:name="android.intent.category.LAUNCHER"/>
            </intent-filter>
        </activity>
    </application>
</manifest>
`
    );

    // Flutter Android Gradle files
    zip.file(
      'flutter_app/android/build.gradle',
      `allprojects {
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.buildDir = "../build"
subprojects {
    project.buildDir = "\${rootProject.buildDir}/\${project.name}"
    project.evaluationDependsOn(":app")
}
tasks.register("clean", Delete) {
    delete rootProject.buildDir
}
`
    );

    zip.file(
      'flutter_app/android/settings.gradle',
      `include ":app"
def localPropertiesFile = new File(rootProject.projectDir, "local.properties")
def properties = new Properties()
if (localPropertiesFile.exists()) {
    localPropertiesFile.withReader("UTF-8") { reader -> properties.load(reader) }
}
def flutterSdkPath = properties.getProperty("flutter.sdk")
if (flutterSdkPath != null) {
    apply from: "$flutterSdkPath/packages/flutter_tools/gradle/app_plugin_loader.gradle"
}
`
    );

    // Flutter Dart main (both in flutter_app/lib/main.dart and root lib/main.dart)
    const mainDartContent = `import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:dhanraj_games/providers/app_provider.dart';
import 'package:dhanraj_games/screens/phone_login_screen.dart';
import 'package:dhanraj_games/screens/home_dashboard_screen.dart';
import 'package:dhanraj_games/theme.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AppProvider()..initialize()),
      ],
      child: const DhanRajApp(),
    ),
  );
}

class DhanRajApp extends StatelessWidget {
  const DhanRajApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Dhan Raj Games',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        primaryColor: const Color(0xFF6B0028),
        scaffoldBackgroundColor: const Color(0xFFF5F5F5),
        textTheme: GoogleFonts.poppinsTextTheme(),
      ),
      home: Consumer<AppProvider>(
        builder: (context, provider, _) {
          return provider.isAuthenticated
              ? const HomeDashboardScreen()
              : const PhoneLoginScreen();
        },
      ),
    );
  }
}
`;

    zip.file('flutter_app/lib/main.dart', mainDartContent);
    zip.file('lib/main.dart', mainDartContent);

    const zipBlob = await zip.generateAsync({
      type: 'blob',
      compression: 'DEFLATE',
      compressionOptions: { level: 6 },
    });

    const blobUrl = window.URL.createObjectURL(zipBlob);
    triggerBlobDownload(blobUrl, filename || 'dhanraj-games-source.zip');

    return {
      success: true,
      message: 'Project Source ZIP packaged and downloaded successfully!',
    };
  } catch (e: any) {
    return {
      success: false,
      message: e.message || 'Client zip fallback failed',
    };
  }
}
