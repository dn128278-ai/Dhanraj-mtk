package com.dhanraj.games

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
