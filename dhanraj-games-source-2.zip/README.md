# 📱 Dhan Raj Games — Mobile App & Automated APK Builder

Official Flutter mobile application and backend for **Dhan Raj Games** (Online Satta Matka, Starline, Jackpot, and Games).

---

## ⚡ How to Build the APK on GitHub (Automated Workflow)

A pre-configured GitHub Actions workflow is located at:
`.github/workflows/build-apk.yml`

Every time you push code to `main` or `master`, GitHub Actions automatically:
1. Sets up **Java 17** & **Java 21** environment.
2. Installs the latest stable **Flutter SDK**.
3. Runs `flutter pub get` to fetch all project packages.
4. Compiles the Android release APK with `flutter build apk --release`.
5. Uploads `app-release.apk` as a downloadable artifact named **`release-apk`**.

---

### 🚀 Step-by-Step Instructions: Push Code to GitHub & Download APK

#### Step 1: Initialize Git and Commit Your Code
Open your terminal inside the project folder:

```bash
# 1. Initialize git repository (if not already done)
git init

# 2. Stage all project files (including .github folder)
git add .

# 3. Commit the changes
git commit -m "feat: complete Dhan Raj Games Flutter app & GitHub Actions workflow"
```

#### Step 2: Push to Your GitHub Repository
Create a new repository on [GitHub](https://github.com/new) (e.g. `dhanraj-games`), then run:

```bash
# Rename branch to main
git branch -M main

# Add your GitHub remote URL (replace YOUR_USERNAME and YOUR_REPO)
git remote add origin https://github.com/YOUR_USERNAME/dhanraj-games.git

# Push the code to GitHub
git push -u origin main
```

#### Step 3: Watch the Build on GitHub Actions
1. Open your repository on GitHub in your web browser.
2. Click on the **"Actions"** tab at the top.
3. You will see a workflow running named **"Build Android Release APK"**.
4. Click on the workflow run to view the live build logs.

#### Step 4: Download Your Built Release APK
1. Once the workflow run completes with a green checkmark (usually takes 2–4 minutes):
2. Scroll down to the **"Artifacts"** section at the bottom of the Summary page.
3. Click on **`release-apk`** to download your zip file containing:
   `app-release.apk`
4. Transfer and install `app-release.apk` directly on any Android device!

---

## 💻 Alternative: Build APK Locally on Your Machine

If you have Flutter and Android SDK installed on your computer:

```bash
# 1. Navigate to flutter_app directory
cd flutter_app

# 2. Get dependencies
flutter pub get

# 3. Build release APK
flutter build apk --release
```

The output APK will be at:
`flutter_app/build/app/outputs/flutter-apk/app-release.apk`

---

## 🌐 Instant Downloads in Web Preview

You can also download the pre-compiled APK and complete project ZIP directly from the web preview header:
- **Download APK** (Green Button) → Serves `/api/download/apk`
- **Download Project ZIP** (Orange Button) → Serves `/api/download/project-zip`
