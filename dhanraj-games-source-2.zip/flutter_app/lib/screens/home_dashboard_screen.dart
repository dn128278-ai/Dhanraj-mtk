import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:dhanraj_games/models/models.dart';
import 'package:dhanraj_games/providers/app_provider.dart';
import 'package:dhanraj_games/screens/game_center_screen.dart';
import 'package:dhanraj_games/theme.dart';

class HomeDashboardScreen extends StatefulWidget {
  const HomeDashboardScreen({super.key});

  @override
  State<HomeDashboardScreen> createState() => _HomeDashboardScreenState();
}

class _HomeDashboardScreenState extends State<HomeDashboardScreen> {
  int _currentTabIndex = 0;

  void _showAddFundsDialog(BuildContext context) {
    final amountController = TextEditingController(text: '1000');
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Add Cash to Wallet', style: TextStyle(fontWeight: FontWeight.bold)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Enter amount to deposit via UPI (GPay/PhonePe/Paytm):', style: TextStyle(fontSize: 13)),
            const SizedBox(height: 12),
            TextField(
              controller: amountController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                prefixText: '₹ ',
                labelText: 'Amount (Min ₹500)',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [500, 1000, 2000, 5000].map((val) {
                return InkWell(
                  onTap: () => amountController.text = val.toString(),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.grey.shade200,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text('+₹$val', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                  ),
                );
              }).toList(),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              final amt = double.tryParse(amountController.text.trim()) ?? 0;
              if (amt < 500) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Minimum deposit is ₹500')),
                );
                return;
              }
              Provider.of<AppProvider>(context, listen: false).addFunds(amt, 'UPI Express');
              Navigator.pop(ctx);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('₹$amt added successfully to wallet!'), backgroundColor: Colors.green),
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: DhanRajTheme.primaryMaroon,
              foregroundColor: Colors.white,
            ),
            child: const Text('Proceed Payment'),
          ),
        ],
      ),
    );
  }

  void _showWithdrawDialog(BuildContext context) {
    final amountController = TextEditingController(text: '1000');
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Withdraw Funds', style: TextStyle(fontWeight: FontWeight.bold)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Enter amount to withdraw to bank account / UPI:', style: TextStyle(fontSize: 13)),
            const SizedBox(height: 12),
            TextField(
              controller: amountController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                prefixText: '₹ ',
                labelText: 'Amount (Min ₹1000)',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Withdrawal Timing: 10:00 AM to 08:00 PM\nTransfer directly to linked Bank / UPI',
              style: TextStyle(fontSize: 11, color: Colors.grey.shade600),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              final amt = double.tryParse(amountController.text.trim()) ?? 0;
              final provider = Provider.of<AppProvider>(context, listen: false);
              if (amt < 1000) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Minimum withdrawal is ₹1000')),
                );
                return;
              }
              final ok = provider.withdrawFunds(amt, 'Bank Account');
              Navigator.pop(ctx);
              if (ok) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Withdrawal request for ₹$amt submitted!'), backgroundColor: Colors.green),
                );
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Insufficient balance in wallet!'), backgroundColor: Colors.redAccent),
                );
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: DhanRajTheme.primaryMaroon,
              foregroundColor: Colors.white,
            ),
            child: const Text('Submit Request'),
          ),
        ],
      ),
    );
  }

  void _showChartDialog(BuildContext context, Market market) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('${market.name} Panel Chart', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.grey.shade100,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  children: [
                    const Text('Past Results Record', style: TextStyle(fontWeight: FontWeight.bold)),
                    const Divider(),
                    _buildChartRow('14-Oct-2026', '230-58-189'),
                    _buildChartRow('15-Oct-2026', '389-01-380'),
                    _buildChartRow('16-Oct-2026', '125-89-469'),
                    _buildChartRow('17-Oct-2026', '789-45-140'),
                    _buildChartRow('18-Oct-2026 (Today)', market.result),
                  ],
                ),
              ),
            ],
          ),
        ),
        actions: [
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx),
            style: ElevatedButton.styleFrom(backgroundColor: DhanRajTheme.primaryMaroon, foregroundColor: Colors.white),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  Widget _buildChartRow(String date, String record) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(date, style: const TextStyle(fontSize: 12, color: Colors.black87)),
          Text(record, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: DhanRajTheme.primaryMaroon)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<AppProvider>(context);

    return Scaffold(
      backgroundColor: const Color(0xFFF7F7F9),
      appBar: AppBar(
        backgroundColor: DhanRajTheme.primaryMaroon,
        elevation: 0,
        title: Row(
          children: [
            const Icon(Icons.casino, color: DhanRajTheme.goldAccent, size: 22),
            const SizedBox(width: 8),
            const Text(
              'DHAN RAJ',
              style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2, fontSize: 17),
            ),
          ],
        ),
        actions: [
          // Wallet Balance Pill
          GestureDetector(
            onTap: () => _showAddFundsDialog(context),
            child: Container(
              margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.18),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: DhanRajTheme.goldAccent.withOpacity(0.6)),
              ),
              child: Row(
                children: [
                  const Icon(Icons.account_balance_wallet, color: DhanRajTheme.goldAccent, size: 16),
                  const SizedBox(width: 6),
                  Text(
                    '₹${provider.balance.toStringAsFixed(0)}',
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Colors.white),
                  ),
                  const SizedBox(width: 4),
                  const Icon(Icons.add_circle, color: DhanRajTheme.goldAccent, size: 16),
                ],
              ),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.notifications_outlined),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('No new notifications at this time.')),
              );
            },
          ),
        ],
      ),
      drawer: _buildDrawer(context, provider),
      body: _buildCurrentTab(provider),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentTabIndex,
        onTap: (index) => setState(() => _currentTabIndex = index),
        type: BottomNavigationBarType.fixed,
        selectedItemColor: DhanRajTheme.primaryMaroon,
        unselectedItemColor: Colors.grey,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.history), label: 'My Bids'),
          BottomNavigationBarItem(icon: Icon(Icons.account_balance_wallet), label: 'Wallet'),
          BottomNavigationBarItem(icon: Icon(Icons.headset_mic), label: 'Support'),
        ],
      ),
    );
  }

  Widget _buildDrawer(BuildContext context, AppProvider provider) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          UserAccountsDrawerHeader(
            decoration: const BoxDecoration(gradient: DhanRajTheme.headerGradient),
            accountName: Text(
              provider.user?.name ?? 'Girish',
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
            ),
            accountEmail: Text(
              '+91 ${provider.user?.phone ?? '7231001800'}  •  ₹${provider.balance.toStringAsFixed(0)}',
              style: const TextStyle(color: DhanRajTheme.goldAccent),
            ),
            currentAccountPicture: CircleAvatar(
              backgroundColor: Colors.white,
              child: Text(
                (provider.user?.name.isNotEmpty == true) ? provider.user!.name[0].toUpperCase() : 'G',
                style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: DhanRajTheme.primaryMaroon),
              ),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.home, color: DhanRajTheme.primaryMaroon),
            title: const Text('Home Dashboard'),
            onTap: () {
              Navigator.pop(context);
              setState(() => _currentTabIndex = 0);
            },
          ),
          ListTile(
            leading: const Icon(Icons.add_card, color: Colors.green),
            title: const Text('Add Cash'),
            onTap: () {
              Navigator.pop(context);
              _showAddFundsDialog(context);
            },
          ),
          ListTile(
            leading: const Icon(Icons.account_balance, color: Colors.orange),
            title: const Text('Withdraw Funds'),
            onTap: () {
              Navigator.pop(context);
              _showWithdrawDialog(context);
            },
          ),
          ListTile(
            leading: const Icon(Icons.receipt_long, color: DhanRajTheme.primaryMaroon),
            title: const Text('Passbook & History'),
            onTap: () {
              Navigator.pop(context);
              setState(() => _currentTabIndex = 1);
            },
          ),
          ListTile(
            leading: const Icon(Icons.support_agent, color: DhanRajTheme.primaryMaroon),
            title: const Text('Customer Helpdesk'),
            subtitle: const Text('WhatsApp: 7231001800'),
            onTap: () {
              Navigator.pop(context);
              setState(() => _currentTabIndex = 3);
            },
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.logout, color: Colors.redAccent),
            title: const Text('Logout', style: TextStyle(color: Colors.redAccent)),
            onTap: () {
              Navigator.pop(context);
              provider.logout();
            },
          ),
        ],
      ),
    );
  }

  Widget _buildCurrentTab(AppProvider provider) {
    switch (_currentTabIndex) {
      case 1:
        return _buildBidsTab(provider);
      case 2:
        return _buildWalletTab(provider);
      case 3:
        return _buildSupportTab();
      case 0:
      default:
        return _buildHomeTab(provider);
    }
  }

  Widget _buildHomeTab(AppProvider provider) {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Announcement Marquee Ticker
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            color: DhanRajTheme.goldAccent.withOpacity(0.2),
            child: Row(
              children: const [
                Icon(Icons.campaign, color: DhanRajTheme.primaryMaroon, size: 20),
                SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Welcome to Dhan Raj Games! 100% Trusted Matka App. Minimum Deposit ₹500. Support: 7231001800',
                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: DhanRajTheme.darkMaroon),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          ),

          // Quick Action Cards
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                _buildActionBtn('Add Cash', Icons.add_circle, Colors.green, () => _showAddFundsDialog(context)),
                const SizedBox(width: 10),
                _buildActionBtn('Withdraw', Icons.account_balance, Colors.orange.shade800, () => _showWithdrawDialog(context)),
                const SizedBox(width: 10),
                _buildActionBtn('Passbook', Icons.receipt_long, Colors.blue.shade700, () => setState(() => _currentTabIndex = 1)),
                const SizedBox(width: 10),
                _buildActionBtn('Support', Icons.chat, DhanRajTheme.primaryMaroon, () => setState(() => _currentTabIndex = 3)),
              ],
            ),
          ),

          // Special Markets Banner (Starline / Jackpot)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Expanded(
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 14),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(colors: [Color(0xFF850533), Color(0xFF50001E)]),
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 4)],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: const [
                        Text('DELHI STARLINE', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
                        SizedBox(height: 4),
                        Text('Result every 15 mins', style: TextStyle(color: DhanRajTheme.goldAccent, fontSize: 11)),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 14),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(colors: [Color(0xFFB45309), Color(0xFF78350F)]),
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 4)],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: const [
                        Text('KING JACKPOT', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
                        SizedBox(height: 4),
                        Text('Win up to 100x Rate', style: TextStyle(color: DhanRajTheme.goldAccent, fontSize: 11)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 18),

          // Markets Header
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Live Markets',
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: Colors.black87),
                ),
                Text(
                  '${provider.markets.length} Markets',
                  style: const TextStyle(fontSize: 13, color: Colors.grey, fontWeight: FontWeight.w600),
                ),
              ],
            ),
          ),

          const SizedBox(height: 8),

          // Markets List
          ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            itemCount: provider.markets.length,
            itemBuilder: (context, index) {
              final market = provider.markets[index];
              return Card(
                elevation: 2,
                margin: const EdgeInsets.only(bottom: 12),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Row(
                    children: [
                      // Market Info
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              market.name,
                              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: DhanRajTheme.primaryMaroon),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              market.result,
                              style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16, color: Colors.black87, letterSpacing: 1.0),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'Open: ${market.openTime} | Close: ${market.closeTime}',
                              style: TextStyle(fontSize: 11, color: Colors.grey.shade600),
                            ),
                          ],
                        ),
                      ),

                      // Chart Button
                      IconButton(
                        icon: const Icon(Icons.table_chart, color: DhanRajTheme.primaryMaroon),
                        onPressed: () => _showChartDialog(context, market),
                        tooltip: 'View Chart',
                      ),

                      const SizedBox(width: 4),

                      // Play Game Button
                      ElevatedButton.icon(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => GameCenterScreen(market: market),
                            ),
                          );
                        },
                        icon: const Icon(Icons.play_arrow, size: 18),
                        label: const Text('PLAY', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: market.isRunning ? DhanRajTheme.primaryMaroon : Colors.grey.shade600,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),

          const SizedBox(height: 24),
        ],
      ),
    );
  }

  Widget _buildActionBtn(String label, IconData icon, Color color, VoidCallback onTap) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: Colors.grey.shade200),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 4)],
          ),
          child: Column(
            children: [
              Icon(icon, color: color, size: 24),
              const SizedBox(height: 4),
              Text(label, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Colors.black87)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBidsTab(AppProvider provider) {
    return provider.bids.isEmpty
        ? Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.history_toggle_off, size: 64, color: Colors.grey.shade400),
                const SizedBox(height: 12),
                const Text('No bids placed yet', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                const SizedBox(height: 6),
                const Text('Your placed bids will appear here in real-time', style: TextStyle(color: Colors.grey, fontSize: 13)),
              ],
            ),
          )
        : ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: provider.bids.length,
            itemBuilder: (context, index) {
              final bid = provider.bids[index];
              return Card(
                margin: const EdgeInsets.only(bottom: 10),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                child: ListTile(
                  title: Text('${bid.marketName} — ${bid.gameType}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                  subtitle: Text('Number: ${bid.number} | Points: ₹${bid.amount.toStringAsFixed(0)}'),
                  trailing: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.amber.shade100,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(bid.status, style: TextStyle(color: Colors.amber.shade900, fontWeight: FontWeight.bold, fontSize: 12)),
                  ),
                ),
              );
            },
          );
  }

  Widget _buildWalletTab(AppProvider provider) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Wallet Balance Card
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: DhanRajTheme.headerGradient,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Available Balance', style: TextStyle(color: Colors.white70, fontSize: 13)),
                const SizedBox(height: 4),
                Text(
                  '₹${provider.balance.toStringAsFixed(2)}',
                  style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: () => _showAddFundsDialog(context),
                        icon: const Icon(Icons.add, size: 18),
                        label: const Text('Add Cash'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: () => _showWithdrawDialog(context),
                        icon: const Icon(Icons.arrow_upward, size: 18),
                        label: const Text('Withdraw'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.orange.shade800,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          const SizedBox(height: 20),
          const Text('Recent Transactions', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),

          if (provider.transactions.isEmpty)
            Container(
              padding: const EdgeInsets.all(24),
              alignment: Alignment.center,
              child: const Text('No transactions yet.', style: TextStyle(color: Colors.grey)),
            )
          else
            ...provider.transactions.map((tx) {
              return Card(
                margin: const EdgeInsets.only(bottom: 8),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: ListTile(
                  leading: Icon(
                    tx.type == 'deposit' ? Icons.arrow_downward : Icons.arrow_upward,
                    color: tx.type == 'deposit' ? Colors.green : Colors.orange,
                  ),
                  title: Text(tx.title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                  subtitle: Text('${tx.date} • ${tx.method}'),
                  trailing: Text(
                    '${tx.type == 'deposit' ? '+' : '-'}₹${tx.amount.toStringAsFixed(0)}',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                      color: tx.type == 'deposit' ? Colors.green : Colors.red,
                    ),
                  ),
                ),
              );
            }),
        ],
      ),
    );
  }

  Widget _buildSupportTab() {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.grey.shade200),
            ),
            child: Column(
              children: [
                const Icon(Icons.support_agent, size: 54, color: DhanRajTheme.primaryMaroon),
                const SizedBox(height: 12),
                const Text(
                  '24x7 Customer Helpdesk',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: DhanRajTheme.primaryMaroon),
                ),
                const SizedBox(height: 6),
                const Text(
                  'We are available 24 hours a day to help you with deposits, withdrawals, and game rules.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 13, color: Colors.grey),
                ),
                const SizedBox(height: 20),
                ListTile(
                  tileColor: Colors.green.shade50,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  leading: const Icon(Icons.chat, color: Colors.green),
                  title: const Text('WhatsApp Support', style: TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: const Text('+91 7231001800'),
                ),
                const SizedBox(height: 10),
                ListTile(
                  tileColor: Colors.blue.shade50,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  leading: const Icon(Icons.call, color: Colors.blue),
                  title: const Text('Call Helpline', style: TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: const Text('+91 7231001800'),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.amber.shade50,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.amber.shade200),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Game Rates Matrix', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                SizedBox(height: 8),
                Text('• Single Digit: 10 KA 95 (1 : 9.5)', style: TextStyle(fontSize: 12)),
                Text('• Jodi Digit: 10 KA 950 (1 : 95)', style: TextStyle(fontSize: 12)),
                Text('• Single Pana: 10 KA 1400 (1 : 140)', style: TextStyle(fontSize: 12)),
                Text('• Double Pana: 10 KA 2800 (1 : 280)', style: TextStyle(fontSize: 12)),
                Text('• Triple Pana: 10 KA 7000 (1 : 700)', style: TextStyle(fontSize: 12)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
