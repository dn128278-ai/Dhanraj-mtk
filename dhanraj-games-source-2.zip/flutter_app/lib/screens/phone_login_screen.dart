import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:dhanraj_games/providers/app_provider.dart';
import 'package:dhanraj_games/theme.dart';

class PhoneLoginScreen extends StatefulWidget {
  const PhoneLoginScreen({super.key});

  @override
  State<PhoneLoginScreen> createState() => _PhoneLoginScreenState();
}

class _PhoneLoginScreenState extends State<PhoneLoginScreen> {
  final TextEditingController _phoneController = TextEditingController(text: '7231001800');
  final TextEditingController _mpinController = TextEditingController(text: '1234');
  final TextEditingController _nameController = TextEditingController(text: 'Girish');

  bool _isMpinMode = false;
  bool _isRegisterMode = false;
  bool _obscurePin = true;

  @override
  void dispose() {
    _phoneController.dispose();
    _mpinController.dispose();
    _nameController.dispose();
    super.dispose();
  }

  void _handlePhoneLogin() {
    final phone = _phoneController.text.trim();
    if (phone.length < 10) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please enter a valid 10-digit mobile number'),
          backgroundColor: Colors.redAccent,
        ),
      );
      return;
    }

    final provider = Provider.of<AppProvider>(context, listen: false);
    provider.setTempPhone(phone);
    // Switch to MPIN mode
    setState(() {
      _isMpinMode = true;
    });
  }

  void _handleMpinLogin() {
    final pin = _mpinController.text.trim();
    if (pin.length < 4) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please enter your 4-digit MPIN'),
          backgroundColor: Colors.redAccent,
        ),
      );
      return;
    }

    final provider = Provider.of<AppProvider>(context, listen: false);
    final success = provider.loginWithMpin(pin);
    if (!success) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Invalid MPIN! Default test MPIN is 1234.'),
          backgroundColor: Colors.redAccent,
        ),
      );
    }
  }

  void _handleRegistration() {
    final name = _nameController.text.trim();
    final phone = _phoneController.text.trim();
    final pin = _mpinController.text.trim();

    if (name.isEmpty || phone.length < 10 || pin.length < 4) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please fill all fields: Name, 10-digit phone, and 4-digit MPIN'),
          backgroundColor: Colors.redAccent,
        ),
      );
      return;
    }

    final provider = Provider.of<AppProvider>(context, listen: false);
    provider.setTempPhone(phone);
    provider.completeRegistration(name, pin);
  }

  void _handleDemoLogin() {
    final provider = Provider.of<AppProvider>(context, listen: false);
    provider.loginDemo();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F7F9),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              // Top Brand Header Banner
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 36, horizontal: 24),
                decoration: const BoxDecoration(
                  gradient: DhanRajTheme.headerGradient,
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(36),
                    bottomRight: Radius.circular(36),
                  ),
                ),
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.12),
                        shape: BoxShape.circle,
                        border: Border.all(color: DhanRajTheme.goldAccent.withOpacity(0.6), width: 2),
                      ),
                      child: const Icon(
                        Icons.casino,
                        color: DhanRajTheme.goldAccent,
                        size: 46,
                      ),
                    ),
                    const SizedBox(height: 14),
                    const Text(
                      'DHAN RAJ GAMES',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 2.0,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      'Trusted Online Matka & Casino Platform',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.85),
                        fontSize: 13,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 24),

              // Form Container Card
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Card(
                  elevation: 4,
                  shadowColor: Colors.black26,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        // Card Title
                        Text(
                          _isRegisterMode
                              ? 'Create Account'
                              : (_isMpinMode ? 'Enter Security MPIN' : 'Login with Mobile'),
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: DhanRajTheme.primaryMaroon,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          _isRegisterMode
                              ? 'Enter your details to register and start playing'
                              : (_isMpinMode
                                  ? 'Enter your 4-digit secret MPIN for ${_phoneController.text}'
                                  : 'Enter your 10-digit registered mobile number'),
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.grey.shade600,
                          ),
                        ),

                        const SizedBox(height: 24),

                        // Registration: Name Field
                        if (_isRegisterMode) ...[
                          TextField(
                            controller: _nameController,
                            decoration: InputDecoration(
                              labelText: 'Full Name',
                              prefixIcon: const Icon(Icons.person, color: DhanRajTheme.primaryMaroon),
                              filled: true,
                              fillColor: Colors.grey.shade100,
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(14),
                                borderSide: BorderSide.none,
                              ),
                            ),
                          ),
                          const SizedBox(height: 16),
                        ],

                        // Phone Field (Shown on Phone login & Register)
                        if (!_isMpinMode || _isRegisterMode) ...[
                          TextField(
                            controller: _phoneController,
                            keyboardType: TextInputType.phone,
                            maxLength: 10,
                            decoration: InputDecoration(
                              labelText: 'Mobile Number',
                              counterText: '',
                              prefixIcon: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
                                child: const Text(
                                  '+91 ',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 15,
                                    color: DhanRajTheme.primaryMaroon,
                                  ),
                                ),
                              ),
                              filled: true,
                              fillColor: Colors.grey.shade100,
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(14),
                                borderSide: BorderSide.none,
                              ),
                            ),
                          ),
                          const SizedBox(height: 16),
                        ],

                        // MPIN Field (Shown on MPIN Mode & Register)
                        if (_isMpinMode || _isRegisterMode) ...[
                          TextField(
                            controller: _mpinController,
                            keyboardType: TextInputType.number,
                            maxLength: 4,
                            obscureText: _obscurePin,
                            decoration: InputDecoration(
                              labelText: '4-Digit MPIN',
                              counterText: '',
                              prefixIcon: const Icon(Icons.lock, color: DhanRajTheme.primaryMaroon),
                              suffixIcon: IconButton(
                                icon: Icon(
                                  _obscurePin ? Icons.visibility_off : Icons.visibility,
                                  color: Colors.grey,
                                ),
                                onPressed: () {
                                  setState(() {
                                    _obscurePin = !_obscurePin;
                                  });
                                },
                              ),
                              filled: true,
                              fillColor: Colors.grey.shade100,
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(14),
                                borderSide: BorderSide.none,
                              ),
                            ),
                          ),
                          const SizedBox(height: 16),
                        ],

                        // Primary Submit Button
                        ElevatedButton(
                          onPressed: () {
                            if (_isRegisterMode) {
                              _handleRegistration();
                            } else if (_isMpinMode) {
                              _handleMpinLogin();
                            } else {
                              _handlePhoneLogin();
                            }
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: DhanRajTheme.primaryMaroon,
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(vertical: 16),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                            elevation: 2,
                          ),
                          child: Text(
                            _isRegisterMode
                                ? 'Register & Enter App'
                                : (_isMpinMode ? 'Sign In with MPIN' : 'Continue with Phone'),
                            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                          ),
                        ),

                        const SizedBox(height: 12),

                        // Mode Switchers
                        if (_isMpinMode) ...[
                          TextButton(
                            onPressed: () => setState(() => _isMpinMode = false),
                            child: const Text('Change Phone Number'),
                          ),
                        ],

                        if (!_isMpinMode) ...[
                          TextButton(
                            onPressed: () => setState(() => _isRegisterMode = !_isRegisterMode),
                            child: Text(
                              _isRegisterMode
                                  ? 'Already registered? Sign In'
                                  : "Don't have an account? Register Now",
                              style: const TextStyle(fontWeight: FontWeight.w600),
                            ),
                          ),
                        ],

                        const Divider(height: 28),

                        // Instant Demo Login Button
                        OutlinedButton.icon(
                          onPressed: _handleDemoLogin,
                          icon: const Icon(Icons.bolt, color: Colors.amber),
                          label: const Text(
                            'One-Tap Demo Login (Girish / ₹2,500)',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: DhanRajTheme.primaryMaroon,
                            side: const BorderSide(color: DhanRajTheme.primaryMaroon),
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 24),

              // Help & Support Card
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.grey.shade200),
                  ),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: Colors.green.shade50,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.support_agent, color: Colors.green, size: 28),
                      ),
                      const SizedBox(width: 14),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Need Help? 24x7 Support',
                              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                            ),
                            Text(
                              'WhatsApp / Call: 7231001800',
                              style: TextStyle(fontSize: 12, color: Colors.grey),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 36),
            ],
          ),
        ),
      ),
    );
  }
}
