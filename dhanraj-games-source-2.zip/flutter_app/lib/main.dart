import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:dhanraj_games/providers/app_provider.dart';
import 'package:dhanraj_games/screens/home_dashboard_screen.dart';
import 'package:dhanraj_games/screens/phone_login_screen.dart';
import 'package:dhanraj_games/theme.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: Color(0xFF50001E),
    ),
  );
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AppProvider()..initialize()),
      ],
      child: const DhanRajApp(),
    ),
  );
}

class DhanRajApp extends StatelessWidget {
  const DhanRajApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Dhan Raj Games',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        primaryColor: const Color(0xFF6B0028),
        scaffoldBackgroundColor: const Color(0xFFF7F7F9),
        textTheme: GoogleFonts.poppinsTextTheme(),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF6B0028),
          foregroundColor: Colors.white,
          elevation: 0,
        ),
      ),
      home: Consumer<AppProvider>(
        builder: (context, provider, _) {
          return provider.isAuthenticated
              ? const HomeDashboardScreen()
              : const PhoneLoginScreen();
        },
      ),
    );
  }
}
