import 'package:flutter/material.dart';

class DhanRajTheme {
  static const Color primaryMaroon = Color(0xFF6B0028);
  static const Color darkMaroon = Color(0xFF50001E);
  static const Color lightMaroon = Color(0xFF850533);
  static const Color goldAccent = Color(0xFFFCD34D);
  static const Color runningGreen = Color(0xFF10B981);
  static const Color closedRed = Color(0xFFE11D48);

  static const LinearGradient headerGradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [primaryMaroon, darkMaroon],
  );
}
