import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import 'providers/app_provider.dart';
import 'screens/home_dashboard_screen.dart';
import 'screens/phone_login_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AppProvider()),
      ],
      child: const DhanRajApp(),
    ),
  );
}

class DhanRajApp extends StatelessWidget {
  const DhanRajApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Dhan Raj Games',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        primaryColor: const Color(0xFF6B0028),
        scaffoldBackgroundColor: const Color(0xFFF5F5F5),
        textTheme: GoogleFonts.poppinsTextTheme(),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF6B0028),
          foregroundColor: Colors.white,
          elevation: 0,
        ),
      ),
      home: Consumer<AppProvider>(
        builder: (context, provider, _) {
          return provider.isAuthenticated
              ? const HomeDashboardScreen()
              : const PhoneLoginScreen();
        },
      ),
    );
  }
}
