import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ArrowLeft, CheckCircle2, Copy, ExternalLink, QrCode, ShieldCheck, XCircle } from 'lucide-react';
import confetti from 'canvas-confetti';

export const AddFundView: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  const { user, addFunds } = useApp();
  const [amount, setAmount] = useState<string>('500');
  const [utr, setUtr] = useState<string>('');
  const [showQr, setShowQr] = useState<boolean>(false);
  const [copiedVpa, setCopiedVpa] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successReceipt, setSuccessReceipt] = useState<{
    utr: string;
    amount: number;
    newBalance: number;
  } | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Configuration Details
  const merchantVpa = '7231001800@nyes';
  const merchantName = 'Dhan Raj Games';
  const transactionNote = 'Wallet Topup';
  const presets = [100, 500, 1000, 2000];

  // Construct valid real-world UPI deep link URL
  const upiDeepLink = `upi://pay?pa=${merchantVpa}&pn=${encodeURIComponent(merchantName)}&am=${amount}&cu=INR&tn=${encodeURIComponent(transactionNote)}`;
  const phonePeDeepLink = `phonepe://pay?pa=${merchantVpa}&pn=${encodeURIComponent(merchantName)}&am=${amount}&cu=INR&tn=${encodeURIComponent(transactionNote)}`;
  const gpayDeepLink = `tez://upi/pay?pa=${merchantVpa}&pn=${encodeURIComponent(merchantName)}&am=${amount}&cu=INR&tn=${encodeURIComponent(transactionNote)}`;
  const paytmDeepLink = `paytmmp://pay?pa=${merchantVpa}&pn=${encodeURIComponent(merchantName)}&am=${amount}&cu=INR&tn=${encodeURIComponent(transactionNote)}`;

  const handleLaunchDeepLink = (appUrl?: string) => {
    const targetUrl = appUrl || upiDeepLink;
    try {
      window.location.href = targetUrl;
    } catch {
      // In web preview if protocol is blocked
    }
  };

  const copyVpa = () => {
    navigator.clipboard.writeText(merchantVpa);
    setCopiedVpa(true);
    setTimeout(() => setCopiedVpa(false), 2500);
  };

  const handleVerifyUtr = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseInt(amount);
    if (!val || val <= 0) {
      setErrorMessage('Please enter a valid amount');
      return;
    }

    const cleanUtr = utr.trim();
    if (cleanUtr.length !== 12 || !/^\d+$/.test(cleanUtr)) {
      setErrorMessage('Please enter a valid 12-digit numeric UTR / UPI Ref ID');
      return;
    }

    setErrorMessage(null);
    setIsSubmitting(true);

    setTimeout(() => {
      setIsSubmitting(false);
      addFunds(val, `UPI (UTR: ${cleanUtr})`);

      const updatedBal = (user?.balance || 0) + val;
      setSuccessReceipt({
        utr: cleanUtr,
        amount: val,
        newBalance: updatedBal,
      });

      confetti({
        particleCount: 90,
        spread: 65,
        origin: { y: 0.6 },
      });
    }, 700);
  };

  return (
    <div className="min-h-full flex flex-col bg-neutral-100 text-neutral-900 pb-20 select-none">
      {/* Top Header */}
      <div className="bg-[#6b0028] text-white px-4 py-3.5 flex items-center gap-3 shadow-md sticky top-0 z-30">
        <button
          onClick={onBack}
          className="p-1 rounded-full hover:bg-white/10 active:scale-95 transition"
        >
          <ArrowLeft size={22} />
        </button>
        <h2 className="text-lg font-bold tracking-wide">Add Money (Real UPI)</h2>
      </div>

      <div className="p-4 flex-1 flex flex-col space-y-4">
        {/* Balance Card */}
        <div className="bg-[#6b0028] text-white rounded-2xl p-5 shadow-lg text-center space-y-1">
          <h3 className="text-lg font-bold tracking-wide">{user?.name || 'Girish'}</h3>
          <p className="text-sm font-semibold tracking-wider text-rose-200">
            {user?.phone || '7231001800'}
          </p>
          <div className="pt-2">
            <span className="text-xs text-rose-200 font-medium">Available Balance</span>
            <div className="text-2xl font-black tracking-tight text-white mt-0.5">
              ₹{user?.balance.toLocaleString('en-IN', { minimumFractionDigits: 2 }) || '0.00'}
            </div>
          </div>
        </div>

        {errorMessage && (
          <div className="p-3 bg-red-50 border border-red-200 text-red-700 rounded-xl text-xs flex items-center gap-2">
            <XCircle size={16} className="text-red-600 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Step 1: Amount & Deep-Linking Trigger */}
        <div className="bg-white rounded-3xl p-5 shadow-xs border border-neutral-200/80 space-y-4">
          <div className="flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-[#6b0028] text-white font-bold text-xs flex items-center justify-center">
              1
            </span>
            <h4 className="font-bold text-sm text-neutral-900">Step 1: Enter Amount & Pay via UPI</h4>
          </div>

          <div className="flex items-center justify-center border-b-2 border-neutral-300 pb-2 focus-within:border-[#6b0028] transition-colors">
            <span className="text-2xl font-bold text-neutral-800 mr-1.5">₹</span>
            <input
              type="number"
              inputMode="numeric"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0"
              className="w-full text-center text-3xl font-extrabold text-[#6b0028] outline-none bg-transparent"
            />
          </div>

          {/* Preset Chips: ₹100, ₹500, ₹1000, ₹2000 */}
          <div className="grid grid-cols-4 gap-2">
            {presets.map((preset) => (
              <button
                key={preset}
                type="button"
                onClick={() => setAmount(preset.toString())}
                className={`py-2 rounded-xl font-bold text-xs border transition-all ${
                  amount === preset.toString()
                    ? 'border-[#6b0028] bg-rose-50 text-[#6b0028] shadow-xs'
                    : 'border-neutral-200 bg-white text-neutral-700 hover:bg-neutral-50'
                }`}
              >
                +₹{preset}
              </button>
            ))}
          </div>

          {/* Quick Deep Link Launchers */}
          <div className="space-y-2 pt-1">
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => handleLaunchDeepLink(phonePeDeepLink)}
                className="py-2.5 px-1 bg-[#5f259f]/10 hover:bg-[#5f259f]/20 text-[#5f259f] border border-[#5f259f]/30 rounded-xl font-bold text-xs flex items-center justify-center gap-1 transition"
              >
                <span>PhonePe</span>
              </button>
              <button
                onClick={() => handleLaunchDeepLink(gpayDeepLink)}
                className="py-2.5 px-1 bg-[#1a73e8]/10 hover:bg-[#1a73e8]/20 text-[#1a73e8] border border-[#1a73e8]/30 rounded-xl font-bold text-xs flex items-center justify-center gap-1 transition"
              >
                <span>Google Pay</span>
              </button>
              <button
                onClick={() => handleLaunchDeepLink(paytmDeepLink)}
                className="py-2.5 px-1 bg-[#00b9f5]/10 hover:bg-[#00b9f5]/20 text-[#002e6e] border border-[#00b9f5]/30 rounded-xl font-bold text-xs flex items-center justify-center gap-1 transition"
              >
                <span>Paytm</span>
              </button>
            </div>

            <button
              onClick={() => handleLaunchDeepLink(upiDeepLink)}
              className="w-full bg-[#6b0028] hover:bg-[#580021] text-white py-3 rounded-xl font-bold text-sm shadow-md active:scale-[0.98] transition flex items-center justify-center gap-2"
            >
              <ExternalLink size={16} />
              <span>Pay ₹{amount} (Open Native UPI App)</span>
            </button>
          </div>
        </div>

        {/* Merchant VPA & Copy / QR details */}
        <div className="bg-white rounded-2xl p-4 shadow-xs border border-neutral-200/80 space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[10px] text-neutral-400 uppercase font-bold tracking-wider">Merchant VPA (UPI ID)</span>
              <div className="font-mono font-bold text-sm text-[#6b0028]">{merchantVpa}</div>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowQr(!showQr)}
                className="p-2 border border-neutral-200 rounded-xl text-neutral-600 hover:bg-neutral-50 transition"
                title="Show QR Code"
              >
                <QrCode size={16} />
              </button>
              <button
                onClick={copyVpa}
                className="px-3 py-2 border border-[#6b0028] text-[#6b0028] rounded-xl font-bold text-xs flex items-center gap-1 hover:bg-rose-50 transition"
              >
                <Copy size={13} />
                <span>{copiedVpa ? 'Copied!' : 'Copy UPI'}</span>
              </button>
            </div>
          </div>

          {showQr && (
            <div className="text-center pt-2 pb-1 border-t border-neutral-100 flex flex-col items-center">
              <img
                src={`https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(upiDeepLink)}`}
                alt="UPI QR Code"
                className="w-40 h-40 border border-neutral-300 rounded-xl p-1 bg-white shadow-xs"
              />
              <span className="text-[11px] text-neutral-500 mt-2 font-medium">Scan using any UPI App to pay ₹{amount}</span>
            </div>
          )}
        </div>

        {/* Step 2: 12-Digit UTR Input Form for Real-Time Credit */}
        <form onSubmit={handleVerifyUtr} className="bg-white rounded-3xl p-5 shadow-xs border border-neutral-200/80 space-y-3">
          <div className="flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-emerald-600 text-white font-bold text-xs flex items-center justify-center">
              2
            </span>
            <h4 className="font-bold text-sm text-neutral-900">Step 2: Enter 12-Digit UTR Number</h4>
          </div>

          <p className="text-xs text-neutral-500 leading-relaxed">
            After paying via PhonePe / GPay / Paytm, copy the 12-digit UTR/UPI Ref ID from your payment receipt and submit below:
          </p>

          <input
            type="text"
            inputMode="numeric"
            maxLength={12}
            value={utr}
            onChange={(e) => setUtr(e.target.value.replace(/\D/g, ''))}
            placeholder="e.g. 428901234567"
            className="w-full py-3 px-4 border border-neutral-300 rounded-xl text-center text-lg font-mono font-bold tracking-widest outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 bg-neutral-50"
          />

          <button
            type="submit"
            disabled={isSubmitting || utr.length !== 12}
            className="w-full bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white py-3 rounded-xl font-bold text-sm shadow-md active:scale-[0.98] transition flex items-center justify-center gap-2"
          >
            {isSubmitting ? (
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <>
                <CheckCircle2 size={16} />
                <span>Verify & Credit ₹{amount} to Wallet</span>
              </>
            )}
          </button>
        </form>

        <div className="text-center text-[11px] text-neutral-400 font-medium py-1">
          100% Genuine Direct Bank UPI Transfer • Instant Credit
        </div>
      </div>

      {/* Payment Verified Receipt Dialog */}
      {successReceipt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto shadow-inner">
              <CheckCircle2 size={36} />
            </div>

            <div>
              <h3 className="text-xl font-bold text-neutral-900">Payment Verified!</h3>
              <p className="text-xs text-neutral-500 mt-0.5">
                ₹{successReceipt.amount.toFixed(2)} credited to your wallet
              </p>
            </div>

            <div className="bg-neutral-50 border border-neutral-200 rounded-2xl p-4 text-xs space-y-2 text-left">
              <div className="flex justify-between items-center">
                <span className="text-neutral-500">12-Digit UTR</span>
                <span className="font-mono font-bold text-neutral-800">{successReceipt.utr}</span>
              </div>
              <div className="border-t border-neutral-200/60 my-1" />
              <div className="flex justify-between items-center">
                <span className="text-neutral-500">Payee VPA</span>
                <span className="font-semibold text-[#6b0028]">{merchantVpa}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-neutral-500">Payee Name</span>
                <span className="font-semibold text-neutral-800">{merchantName}</span>
              </div>
              <div className="border-t border-neutral-200/60 my-1" />
              <div className="flex justify-between items-center font-bold text-sm">
                <span className="text-neutral-800">Updated Balance</span>
                <span className="text-emerald-600">₹{successReceipt.newBalance.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
              </div>
            </div>

            <button
              onClick={() => {
                setSuccessReceipt(null);
                onBack();
              }}
              className="w-full py-3.5 bg-[#6b0028] text-white font-bold rounded-xl shadow-md hover:bg-[#580021] active:scale-[0.98] transition"
            >
              Back to Wallet
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
