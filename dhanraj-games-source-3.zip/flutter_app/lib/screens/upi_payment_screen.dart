import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:dhanraj_games/providers/app_provider.dart';
import 'package:dhanraj_games/theme.dart';

class UpiPaymentScreen extends StatefulWidget {
  final double initialAmount;
  const UpiPaymentScreen({super.key, this.initialAmount = 500});

  @override
  State<UpiPaymentScreen> createState() => _UpiPaymentScreenState();
}

class _UpiPaymentScreenState extends State<UpiPaymentScreen> {
  final TextEditingController _amountController = TextEditingController();
  final TextEditingController _utrController = TextEditingController();

  static const String merchantUpiId = '7231001800@nyes';
  static const String merchantName = 'Dhan Raj Games';
  static const String transactionNote = 'Wallet Topup';

  final List<int> _presetChips = [100, 500, 1000, 2000];

  bool _hasLaunchedPayment = false;
  bool _isSubmittingUtr = false;
  String _selectedUpiApp = 'any'; // 'any', 'phonepe', 'gpay', 'paytm'

  @override
  void initState() {
    super.initState();
    _amountController.text = widget.initialAmount.toStringAsFixed(0);
  }

  @override
  void dispose() {
    _amountController.dispose();
    _utrController.dispose();
    super.dispose();
  }

  /// Constructs the standard UPI Intent URL string
  String _buildUpiUrl({String? appScheme}) {
    final amount = _amountController.text.trim();
    final encodedName = Uri.encodeComponent(merchantName);
    final encodedNote = Uri.encodeComponent(transactionNote);

    final query = 'pa=$merchantUpiId&pn=$encodedName&am=$amount&cu=INR&tn=$encodedNote';

    if (appScheme == 'phonepe') {
      return 'phonepe://pay?$query';
    } else if (appScheme == 'gpay') {
      return 'tez://upi/pay?$query';
    } else if (appScheme == 'paytm') {
      return 'paytmmp://pay?$query';
    }

    // Default universal UPI deep-link
    return 'upi://pay?$query';
  }

  /// Triggers the native UPI intent via url_launcher
  Future<void> _launchUpiIntent({String? appScheme}) async {
    final double? amt = double.tryParse(_amountController.text.trim());
    if (amt == null || amt <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please enter a valid amount'),
          backgroundColor: Colors.redAccent,
        ),
      );
      return;
    }

    final urlString = _buildUpiUrl(appScheme: appScheme);
    final uri = Uri.parse(urlString);

    try {
      final launched = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!launched) {
        // Fallback to universal upi://pay scheme
        final fallbackUri = Uri.parse(_buildUpiUrl());
        await launchUrl(fallbackUri, mode: LaunchMode.externalApplication);
      }

      setState(() {
        _hasLaunchedPayment = true;
      });
    } catch (e) {
      // In case device has no dedicated app for specific scheme, try universal
      try {
        final fallbackUri = Uri.parse(_buildUpiUrl());
        await launchUrl(fallbackUri, mode: LaunchMode.externalApplication);
        setState(() {
          _hasLaunchedPayment = true;
        });
      } catch (err) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Could not open UPI app: $err\nPlease copy the UPI ID below and pay directly.'),
            backgroundColor: Colors.redAccent,
          ),
        );
      }
    }
  }

  /// Copies the VPA to device clipboard
  void _copyVpa() {
    Clipboard.setData(const ClipboardData(text: merchantUpiId));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('UPI ID copied: 7231001800@nyes'),
        backgroundColor: Colors.green,
        duration: Duration(seconds: 2),
      ),
    );
  }

  /// Verifies and credits real money balance using the 12-digit UTR
  void _submitUtr() {
    final utr = _utrController.text.trim();
    final double? amt = double.tryParse(_amountController.text.trim());

    if (amt == null || amt <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a valid amount')),
      );
      return;
    }

    if (utr.length != 12) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please enter a valid 12-digit UTR / UPI Ref number'),
          backgroundColor: Colors.redAccent,
        ),
      );
      return;
    }

    setState(() {
      _isSubmittingUtr = true;
    });

    // Credit to AppProvider wallet balance and save to passbook
    final provider = Provider.of<AppProvider>(context, listen: false);
    final txnId = 'DRG_UTR_$utr';
    provider.addFunds(amt, 'UPI Intent (UTR: $utr)', refId: txnId);

    setState(() {
      _isSubmittingUtr = false;
    });

    _showSuccessDialog(amt, utr, provider.balance);
  }

  void _showSuccessDialog(double amount, String utr, double newBalance) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        contentPadding: const EdgeInsets.all(24),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.green.shade50,
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.check_circle, color: Colors.green, size: 54),
            ),
            const SizedBox(height: 16),
            const Text(
              'Payment Verified!',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20, color: Colors.black87),
            ),
            const SizedBox(height: 6),
            Text(
              '₹${amount.toStringAsFixed(2)} credited to your wallet',
              style: TextStyle(fontSize: 14, color: Colors.grey.shade600, fontWeight: FontWeight.w500),
            ),
            const SizedBox(height: 18),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.grey.shade100,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                children: [
                  _buildReceiptRow('12-Digit UTR', utr, isMonospace: true),
                  const Divider(height: 16),
                  _buildReceiptRow('Payee VPA', merchantUpiId),
                  const Divider(height: 16),
                  _buildReceiptRow('Updated Balance', '₹${newBalance.toStringAsFixed(2)}', isBold: true),
                ],
              ),
            ),
            const SizedBox(height: 22),
            SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.pop(ctx); // Close dialog
                  Navigator.pop(context); // Return to home/wallet
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: DhanRajTheme.primaryMaroon,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                ),
                child: const Text('Back to Wallet', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildReceiptRow(String label, String value, {bool isBold = false, bool isMonospace = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: TextStyle(fontSize: 12, color: Colors.grey.shade700)),
        Flexible(
          child: Text(
            value,
            textAlign: TextAlign.end,
            style: TextStyle(
              fontSize: 12,
              fontWeight: isBold ? FontWeight.bold : FontWeight.w600,
              fontFamily: isMonospace ? 'monospace' : null,
              color: isBold ? DhanRajTheme.primaryMaroon : Colors.black87,
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<AppProvider>(context);

    return Scaffold(
      backgroundColor: const Color(0xFFF7F7F9),
      appBar: AppBar(
        title: const Text('Add Money (Real UPI)', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
        backgroundColor: DhanRajTheme.primaryMaroon,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Balance Card
            Container(
              padding: const EdgeInsets.all(20),
              decoration: const BoxDecoration(
                gradient: DhanRajTheme.headerGradient,
                borderRadius: BorderRadius.all(Radius.circular(22)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        provider.user?.name ?? 'Girish',
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.18),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          provider.user?.phone ?? '7231001800',
                          style: const TextStyle(color: DhanRajTheme.goldAccent, fontSize: 12, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  const Text('Current Wallet Balance', style: TextStyle(color: Colors.white70, fontSize: 12)),
                  const SizedBox(height: 4),
                  Text(
                    '₹${provider.balance.toStringAsFixed(2)}',
                    style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w900),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 20),

            // Step 1: Amount Selection & Deep Link Trigger
            Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
              elevation: 2,
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(6),
                          decoration: const BoxDecoration(
                            color: DhanRajTheme.primaryMaroon,
                            shape: BoxShape.circle,
                          ),
                          child: const Text('1', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12)),
                        ),
                        const SizedBox(width: 8),
                        const Text(
                          'Step 1: Enter Amount & Pay',
                          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: Colors.black87),
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),

                    // Amount input
                    TextField(
                      controller: _amountController,
                      keyboardType: TextInputType.number,
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 32, fontWeight: FontWeight.w900, color: DhanRajTheme.primaryMaroon),
                      decoration: InputDecoration(
                        prefixIcon: const Padding(
                          padding: EdgeInsets.only(left: 16, top: 8),
                          child: Text('₹', style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: DhanRajTheme.primaryMaroon)),
                        ),
                        filled: true,
                        fillColor: Colors.grey.shade100,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(16),
                          borderSide: BorderSide.none,
                        ),
                        hintText: '0',
                      ),
                    ),

                    const SizedBox(height: 14),

                    // Preset Chips: ₹100, ₹500, ₹1000, ₹2000
                    Row(
                      children: _presetChips.map((preset) {
                        final isSelected = _amountController.text == preset.toString();
                        return Expanded(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 4),
                            child: OutlinedButton(
                              onPressed: () {
                                setState(() {
                                  _amountController.text = preset.toString();
                                });
                              },
                              style: OutlinedButton.styleFrom(
                                backgroundColor: isSelected ? DhanRajTheme.primaryMaroon.withOpacity(0.08) : Colors.white,
                                side: BorderSide(
                                  color: isSelected ? DhanRajTheme.primaryMaroon : Colors.grey.shade300,
                                  width: isSelected ? 2 : 1,
                                ),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                padding: const EdgeInsets.symmetric(vertical: 8),
                              ),
                              child: Text(
                                '+₹$preset',
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  color: isSelected ? DhanRajTheme.primaryMaroon : Colors.black87,
                                ),
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                    ),

                    const SizedBox(height: 18),

                    // Specific UPI App Trigger Buttons
                    const Text(
                      'Choose Your UPI App:',
                      style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.black87),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () => _launchUpiIntent(appScheme: 'phonepe'),
                            style: OutlinedButton.styleFrom(
                              side: const BorderSide(color: Color(0xFF5F259F)),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                              padding: const EdgeInsets.symmetric(vertical: 10),
                            ),
                            child: const Text('PhonePe', style: TextStyle(color: Color(0xFF5F259F), fontWeight: FontWeight.bold)),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () => _launchUpiIntent(appScheme: 'gpay'),
                            style: OutlinedButton.styleFrom(
                              side: const BorderSide(color: Color(0xFF1A73E8)),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                              padding: const EdgeInsets.symmetric(vertical: 10),
                            ),
                            child: const Text('GPay', style: TextStyle(color: Color(0xFF1A73E8), fontWeight: FontWeight.bold)),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () => _launchUpiIntent(appScheme: 'paytm'),
                            style: OutlinedButton.styleFrom(
                              side: const BorderSide(color: Color(0xFF00B9F5)),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                              padding: const EdgeInsets.symmetric(vertical: 10),
                            ),
                            child: const Text('Paytm', style: TextStyle(color: Color(0xFF002E6E), fontWeight: FontWeight.bold)),
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 12),

                    // Universal Pay Now Deep Link Button
                    SizedBox(
                      height: 50,
                      child: ElevatedButton.icon(
                        onPressed: () => _launchUpiIntent(),
                        icon: const Icon(Icons.open_in_new, size: 18),
                        label: Text(
                          'Pay Now (₹${_amountController.text})',
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: DhanRajTheme.primaryMaroon,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                          elevation: 3,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 18),

            // Merchant VPA & Copy Card
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: Colors.grey.shade200),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Text('Merchant VPA (UPI ID)', style: TextStyle(fontSize: 11, color: Colors.grey)),
                      SizedBox(height: 2),
                      Text(
                        merchantUpiId,
                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: DhanRajTheme.primaryMaroon),
                      ),
                    ],
                  ),
                  OutlinedButton.icon(
                    onPressed: _copyVpa,
                    icon: const Icon(Icons.copy, size: 14),
                    label: const Text('Copy'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: DhanRajTheme.primaryMaroon,
                      side: const BorderSide(color: DhanRajTheme.primaryMaroon),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 18),

            // Step 2: 12-Digit UTR Entry & Real-Time Balance Credit
            Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
              elevation: 2,
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(6),
                          decoration: BoxDecoration(
                            color: _hasLaunchedPayment ? Colors.green : Colors.grey.shade700,
                            shape: BoxShape.circle,
                          ),
                          child: const Text('2', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12)),
                        ),
                        const SizedBox(width: 8),
                        const Text(
                          'Step 2: Enter 12-Digit UTR Number',
                          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: Colors.black87),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'After completing payment in PhonePe/GPay/Paytm, copy the 12-digit UTR/UPI Ref No. and submit below to credit wallet immediately.',
                      style: TextStyle(fontSize: 12, color: Colors.grey.shade600, height: 1.3),
                    ),
                    const SizedBox(height: 14),

                    TextField(
                      controller: _utrController,
                      keyboardType: TextInputType.number,
                      maxLength: 12,
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, letterSpacing: 2.0),
                      decoration: InputDecoration(
                        counterText: '',
                        labelText: '12-Digit UTR / UPI Ref ID',
                        hintText: 'e.g. 428901234567',
                        prefixIcon: const Icon(Icons.receipt_long, color: DhanRajTheme.primaryMaroon),
                        filled: true,
                        fillColor: Colors.grey.shade100,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(14),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),

                    const SizedBox(height: 14),

                    SizedBox(
                      height: 48,
                      child: ElevatedButton.icon(
                        onPressed: _isSubmittingUtr ? null : _submitUtr,
                        icon: const Icon(Icons.verified, size: 18),
                        label: _isSubmittingUtr
                            ? const SizedBox(
                                height: 20,
                                width: 20,
                                child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                              )
                            : const Text('Submit UTR & Credit Wallet', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 18),

            // Security note
            Center(
              child: Text(
                '100% Genuine Direct Bank UPI Transfer • Instant Credit',
                style: TextStyle(fontSize: 11, color: Colors.grey.shade500, fontWeight: FontWeight.w500),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
